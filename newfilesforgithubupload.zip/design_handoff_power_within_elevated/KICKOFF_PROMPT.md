# Claude Code Kickoff Prompt

Paste this into Claude Code, opened at the root of the `power-within-movement-react` repo, with the `design_handoff_power_within_elevated/` folder placed inside it.

---

I'm implementing an approved visual redesign of this app. The full spec and reference prototypes are in `design_handoff_power_within_elevated/` — **read `design_handoff_power_within_elevated/README.md` first, in full, before writing any code.**

Context:
- Stack is React 19 + Vite + react-router-dom v7 + framer-motion (already installed). Styles currently live in `src/styles/global.css`.
- The `.dc.html` files in the handoff are **design references, not code to copy** — recreate their look in this codebase's existing pages/components. `site/index.dc.html` is a working responsive Home page; treat its CSS (fluid `clamp()` type, 980px breakpoint, hamburger nav, `auto-fit` grids) as the responsive source of truth for every screen.
- Photography already exists at `src/assets/images/` — reuse it; don't generate new art or SVG icons.

Design language (see README "Design Tokens" for exact values): editorial luxury — Cormorant Garamond display + Manrope body, cream/plum/mauve/soft-gold palette, oversized headings, hairline dividers instead of boxed cards, one accent (plum = action, gold = eyebrow), generous whitespace. Mobile is a first-class requirement, not a pass — follow the README "Responsive & Mobile Specification" exactly.

Please work in this order, pausing after each step so I can review:
1. Add the Google Fonts and establish shared design tokens + a reusable responsive `Nav` (with hamburger) and `Footer` matching `site/index.dc.html`.
2. Rebuild the **Home** page (`src/pages/Home.jsx`) to match the reference exactly, fully responsive.
3. Roll the same system across the remaining public pages: Experiences, The Vault (`Resources.jsx`), Professionals, Podcast, Teen Programs, About, Contact, Client Login.
4. Rebuild the **Client Portal** dashboard (`ClientPortalDashboard.jsx`) — sidebar-free, per prototype `8a`.
5. Rebuild the **admin studio** in the airy sidebar-free language: Founders View (`4b`), The Studio home (`7a`), Sessions (`7b`), Mail Studio (`7c`), Activity Journal (`7d` — convert the raw UUID dump to plain-English day-grouped events), Client Circle (`6b`).

Keep all existing data flows (`src/lib/nativeApi.js`), routes, and auth guards intact — this is a visual layer only. Verify each screen reflows correctly at mobile, tablet, and desktop widths before moving on.
