# Handoff: Power Within Collective — Elevated ("Apple-like") Redesign

## Overview
A full visual elevation of the Power Within Collective product — public marketing site, client portal, and admin studio — into a single restrained, editorial-luxury design language (reference points: Aesop, RH, Loewe). The goals: extreme whitespace, one idea per section, hairline dividers instead of boxed cards, oversized confident serif display, real photography leading, and one strict accent discipline. Every surface now shares the same nav rhythm, type scale, and section grammar so the whole product reads as one premium system.

## About the Design Files
The file in this bundle (`Client Portal - Polished.dc.html`) is a **design reference created in HTML** — a single-file prototype showing intended look, layout, and copy. It is **not production code to copy directly.**

The target codebase already exists: **`Sikatu/power-within-movement-react`** — React 19 + Vite + `react-router-dom` v7 + `framer-motion`, with all styles currently in `src/styles/global.css`. The task is to **recreate these designs in that codebase** using its existing component/page structure (`src/pages/*`, `src/components/*`), replacing the current screen styles with the tokens and layouts documented below. Do not ship the HTML prototype itself.

The prototype is laid out as a horizontal "design canvas": each screen is a `<section>`/option with a stable id badge (e.g. `4a`, `5c`, `8a`). Those ids are referenced throughout this README so you can find any screen in the file.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, and layout are intentional and specified below with exact values. Recreate pixel-close using the codebase's existing React patterns. Copy is final-draft (illustrative where noted) — confirm real content with the owner before launch.

---

## Design Tokens

### Typography
- **Display / headings:** `"Cormorant Garamond", Georgia, serif` — weights 500 & 600. Used for all H1/H2/H3, stat numerals, names, quote text.
- **Body / UI:** `"Manrope", system-ui, sans-serif` — weights 400, 500, 600, 700, 800. Used for body copy, eyebrows, labels, buttons, meta.
- Load both from Google Fonts (Cormorant Garamond ital,wght@0,500;0,600;1,500 + Manrope wght@400..800).

Type scale (elevated):
| Role | Family | Size | Weight | Line-height | Tracking |
|---|---|---|---|---|---|
| Home hero H1 | Cormorant | 112px | 600 | .90 | -.02em |
| Subpage hero H1 | Cormorant | 78–88px | 600 | .94 | -.01em |
| Section H2 | Cormorant | 40–64px | 600 | 1.0–1.02 | -.01em |
| Row / card title H3 | Cormorant | 22–34px | 600 | 1.0 | — |
| Stat numeral | Cormorant | 46–58px | 600 | 1.0 | — |
| Quote (italic) | Cormorant italic | 52px | 500 | 1.12 | — |
| Eyebrow | Manrope | 11px | 700 | — | .24–.28em, UPPERCASE |
| Lede / body | Manrope | 14–16px | 400 | 1.65–1.75 | — |
| Meta / label | Manrope | 11.5–13.5px | 600–700 | — | .04–.16em where labelled |

### Colors
- **Backgrounds (cream/ivory):** page `linear-gradient(180deg,#faf3ec,#f6ece4)`; lighter fields `#fbf7f2` / `#f9f2ec`. Ambient hero glow: `radial-gradient(58% 46% at 50% 6%, rgba(234,211,203,.55), transparent 70%)`.
- **Surfaces / panels:** `rgba(255,252,249,.6–.85)`.
- **Headings:** `#33222a` (primary), `#3a2528`.
- **Body text:** `#8a7a72` (warm gray), secondary `#9a8a82`, muted/italic `#a89a92`.
- **Eyebrow gold:** `#b5884d` (primary), soft-gold `#c8a96a`, deep `#a8863f` / `#8a6a3f`.
- **Accent — action (plum):** solid `#4d2831`; button gradient `linear-gradient(160deg,#4d2831,#38202a)`; link/hover `#7c514b` → `#4d2831`.
- **Deep-plum surfaces:** quote band `linear-gradient(160deg,#3a2528,#2b1c21)`; footer `linear-gradient(180deg,#2f2024,#241619)`; footer text `rgba(228,211,202,.6–.8)`; footer eyebrow `#c8a96a`.
- **Hairline rule (the core divider):** `1px solid rgba(124,81,75,.10–.16)`.
- **Status tags:** success green text `#5b8c6e` / bg `rgba(91,140,110,.13)`; pending gold text `#a8863f` / bg `rgba(200,169,106,.18)`; failed rust text `#b06a5a` / bg `rgba(176,106,90,.15)`.

### Spacing, radius, shadow
- **Section padding:** ~100px vertical, 60–72px horizontal (desktop). Hairline-divided blocks: ~40–52px padding above the rule.
- **Content max width:** public pages full-bleed inside a ~1440px shell; admin/portal ~1120–1180px.
- **Radius:** pills/buttons `999px`; images `18–22px`; panels `20–22px`; phone frame `52px` outer / `41px` screen.
- **Shadow (sparingly):** `0 40–50px 80–100px -50px rgba(58,37,40,.5–.6)`.
- **Buttons:** *Solid pill* — plum gradient, text `#f7ede7`, padding `15px 30px`, shadow `0 18px 34px -18px rgba(58,37,40,.9)`. *Ghost pill* — `rgba(255,255,255,.5)`, text `#4d2831`, `1px solid rgba(124,81,75,.25)`.

### Shared chrome (every public page inherits)
- **Nav:** transparent-cream bar, 20px/48px padding, bottom hairline. Left: logo mark (32px) + `Power Within Collective` in 19px Cormorant 600. Center: links in 12px Manrope 600, `.06em` tracking, `#6f5b57` (active `#3a2528`). Right: `Client Login` ghost pill.
- **Footer:** deep-plum, 4-column grid (brand+blurb / Explore / Resources / Stay Connected), gold uppercase H4 labels, `Join the Newsletter` pill, centered legal line.
- **Section grammar:** tiny gold eyebrow → oversized Cormorant heading → optional lede → content divided by hairlines (never boxed cards).

---

## Screens / Views
Each maps to an existing page/component in the repo. IDs = location in the prototype file.

### Public site (recreate in `src/pages/*`, shared nav/footer in `src/components/`)
- **Home** (`4a`) → `Home.jsx`. Hero: eyebrow, 112px "Return to / who you are.", lede, two CTAs, then full-bleed `hero.webp` in a rounded frame. Then: "It is layered" 3-column hairline triad (Confidence / Energy / Identity); founder split (`kim.webp` + "The right colors were not always enough."); experiences 3-up image grid; full-bleed plum quote; closing CTA; footer.
- **Experiences** (`5a`) → `Experiences.jsx`. Hero "This is not a makeover. It is a return." + "Ways to Begin" triad (Radiance Reclaimed™ / Power Shift Clarity / Personalized Appointments) + complimentary-consult CTA.
- **The Vault** (`5b`) → `Resources.jsx`. Hero "Not more information. A place to return to yourself." + split (`story.webp` + "Most women are not struggling because they lack information.") + Enter/Free CTAs.
- **Professionals** (`5c`) → `Professionals.jsx`. Hero "The future of beauty is not just service. It is transformation." + "Signature Experience Method" triad (Recognize the Gap / Restore the Standard / Build the Experience) + CTA.
- **Podcast** (`5d`) → `Podcast.jsx`. Hero "Conversations for confidence…" + split (square `podcast.webp` + platform pills: Apple / Spotify / YouTube).
- **Teen Programs** (`5e`) → `TeenPrograms.jsx`. Hero "Confidence she can grow into, not perform for." + split (`teen.webp` + "She needs steadier places to become herself.").
- **About** (`5f`) → `About.jsx`. Hero "The foundation behind Power Within Collective™." + founder split (`kim.webp`) + plum quote + closing CTA.
- **Contact** (`5g`) → `Contact.jsx`. Hero "You do not have to have it figured out…" + two-col (message form: name/email/select/submit) + doorways list (`contact.webp` + Book a Clarity Session / Book Kim to Speak) + footer.
- **Client Login** (`5h`) → `ClientPortalLogin.jsx`. Split: left "Your private space for care." + trust chips; right login card (email, password, "Enter My Portal", invite note).

### Client portal (recreate in `src/pages/ClientPortal*`)
- **Client Portal Dashboard** (`8a`) → `ClientPortalDashboard.jsx`. Sidebar-free. Eyebrow + "Welcome, Cherry.", 4-stat strip (Visible Notes / Resources / Sessions / Follow-Ups), Featured Resource hairline band, "Your Library" (Guides + Links as hairline rows), "Shared With You" note + Next Steps / Session History side column, "Recent Service History" hairline table. Nav right: Power Within Website + Sign Out.

### Admin studio (recreate in `src/pages/admin/*` — NOTE: this replaces the deep-plum sidebar with the airy sidebar-free owner language)
- **Founders View** (`4b`) → `AdminFoundersView.jsx`. Minimal top nav "The Studio", "Good afternoon, Darelle.", 4-stat strip, one focal Next Session row (avatar + name + time), a single Block-Time row (Unavailable today / Block tomorrow / Pick a date), calm empty states. **Fix from current build:** no blank pills or invisible submit — every control reads finished.
- **The Studio (home)** (`7a`) → `AdminDashboard.jsx`. Eyebrow + "The Studio.", 4-stat strip, "Follow-Up Care Queue" empty section, two hairline lists (Coming Up / Recent Movement).
- **Sessions & Calendar** (`7b`) → `AdminScheduler.jsx` / `SessionRequest.jsx`. Hero "Hold the rhythm of the work.", 4-stat strip, "Session Requests" hairline row, Session Types + Availability hairline rows.
- **Mail Studio** (`7c`) → `AdminMailStudio.jsx`. Hero "Mail Studio.", 4-stat strip, minimal composer (Client + Template selects + Send), recent email activity as hairline rows with status tags.
- **Activity Journal** (`7d`) → `AdminAuditLog.jsx`. **Biggest change:** the raw UUID/`afterData` dump becomes plain-English events grouped by day ("Cherry accepted her client portal invite" — actor + entity + time), with technical detail hidden behind a details affordance. Gold dot markers, hairline rows.
- **Client Circle** (`6b`) → `AdminClients.jsx`. "Private Client Records" as hairline rows (name in Cormorant, email, status tag, View/Edit link) + "Welcome Someone In" primary action + Care Notes empty prompt.

### Mobile
- **Home — mobile** (`6a`). Phone frame: light top bar (logo + hamburger), centered 52px Cormorant hero, full-width solid CTA, rounded `hero.webp`, then stacked hairline triad. Apply the same collapse pattern (nav → top bar, columns → single column, rows stay hairline) to all pages. Min touch target 44px.

## Interactions & Behavior
- **Nav:** links route between pages (react-router). Active link darkens to `#3a2528`. Consider a slim sticky/translucent nav on scroll.
- **Buttons/links:** solid = primary action, ghost = secondary. Link arrows ("Open →", "View / Edit →") on hover shift color `#7c514b`→`#4d2831`.
- **Motion (framer-motion, already a dependency):** keep it restrained — hero and section fade/slide-up on enter (~400–600ms, ease-out), staggered by ~60ms for grid/triad children. No bounce. Images can have a subtle scale-in.
- **Forms:** Contact + Login + admin create-forms — standard validation (required, email format), plum focus ring on inputs (`1px` border → plum). Submit shows a pending state then success.
- **Empty states:** italic muted single lines (e.g. "No follow-up reminders are active right now.") — keep them, they're part of the calm tone.
- **Responsive:** ≥1024px as designed; below, collapse multi-column sections to one column, reduce hero to 44–56px, nav to a hamburger. Preserve hairline dividers and whitespace rhythm.

## State Management
Unchanged from current app — this is a visual layer. Existing data flows in `src/lib/nativeApi.js` (client portal dashboard/resources, logout; admin clients/sessions/mail/audit) remain the source of truth. Key states per screen: loading / error / empty / populated (portal dashboard already implements these — preserve them). Auth-gated routes stay via the existing route guards.

## Assets
All photography already lives in the repo at `src/assets/images/` and is reused as-is:
`hero.webp` (founder portrait, Home hero), `kim.webp` (founder, About/Home split), `story.webp` (The Vault), `radiance.webp`, `professionals.webp`, `teen.webp` (experiences grid + subpage heroes), `podcast.webp` (Podcast cover), `contact.webp` (Contact), `logo.webp` (nav/footer mark). Copies are included in this bundle under `src/assets/images/` for convenience. No new assets required. No SVG-drawn icons were introduced.

## Responsive & Mobile Specification (mobile is locked-in, not an afterthought)
A **working, fully responsive reference implementation of the Home page** is included at `site/index.dc.html` — open it and resize the window (or open on a phone) to see the exact intended reflow. Recreate these rules on every screen:

- **Breakpoint:** one primary breakpoint at **980px**. ≥980px = multi-column desktop; <980px = stacked mobile/tablet.
- **Fluid typography (continuous, no hard jumps):** use `clamp()`. Reference values — hero H1 `clamp(44px,8.5vw,112px)`; section H2 `clamp(34px,5vw,60px)`; H3 `clamp(24px,2.6vw,32px)`; body `clamp(14px,1.7vw,16px)`; eyebrow `clamp(9.5px,1.4vw,11px)`. Section padding `clamp(64px,9vw,100px)` vertical; page gutter `clamp(20px,5vw,60px)`.
- **Navigation:** sticky translucent (blur) bar. ≥980px = inline links + Client Login pill. <980px = links collapse into a **hamburger (☰)** toggling a full-width dropdown; tap-outside closes it. (Vanilla JS toggle in the reference file; use component state in React.)
- **Grids stack automatically:** triads, experience cards, and split (image+text) sections use `grid-template-columns:repeat(auto-fit,minmax(Xpx,1fr))` (X ≈ 230–300) so they collapse 3-col → 2 → 1 with no extra breakpoints. Split sections stack image-over-text on mobile.
- **Images:** `width:100%;max-width:100%` with fixed `aspect-ratio` (16/8 hero, 4/5 portraits & cards, 1/1 podcast) + `object-fit:cover`.
- **Touch targets:** buttons/links ≥ 44px tall on mobile; dropdown items full-width with 14px padding.
- **Container:** 1240px max-width, centered, on every page.
- **Portal + admin** reflow the same way — the sidebar-free layouts stack cleanly, stat strips wrap, and hairline rows become stacked label/value on narrow widths.

**Feasibility (you asked): yes, 100%.** Everything here is standard, production-ready HTML/CSS — Google Fonts (Cormorant Garamond + Manrope), flexbox/grid, `clamp()`, one media query, a tiny nav toggle. Nothing exotic; it implements cleanly in the existing React 19 + Vite app.

## Files
- `Client Portal - Polished.dc.html` — the full prototype; every screen above is a section keyed by its id (`4a`, `4b`, `5a`–`5h`, `6a`, `6b`, `7a`–`7d`, `8a`).
- `site/index.dc.html` — a **working responsive Home page** (real reflow, hamburger nav, fluid type). Use it as the concrete mobile/desktop reference for all pages.
- `support.js` — runtime needed only to open the prototypes in a browser. **Not** for production.
- `src/assets/images/*` — the photography used.

To view the prototype: open `Client Portal - Polished.dc.html` in a browser and pan/zoom the canvas; each labelled section is one screen.
